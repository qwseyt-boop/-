#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#include <minecraft:globals.glsl>
uniform sampler2D Sampler0;
layout(location = 4) flat out ivec3 aeroWallet;
layout(location = 5) out vec2 aeroWalletUV;

void aeroWalletGlyph() {
    aeroWallet = ivec3(0);
    aeroWalletUV = vec2(0.0);
    if (any(notEqual(textureSize(Sampler0, 0), ivec2(256)))) return;
    ivec2 corner = ivec2(greaterThan(UV0 * 256.0, vec2(128.0)));
    ivec2 origin = ivec2(round(UV0 * 256.0)) - corner * ivec2(243, 198);
    if (any(lessThan(origin, ivec2(0))) || any(greaterThan(origin, ivec2(13, 58)))) return;
    ivec4 marker = ivec4(round(texelFetch(Sampler0, origin, 0) * 255.0));
    if (any(notEqual(marker.rgb, ivec3(29, 183, 241))) || marker.a < 251 || marker.a > 254) return;
    aeroWallet = ivec3(origin, marker.a - 250);
    aeroWalletUV = vec2(corner);
    // Minecraft draws the default text shadow at one quarter brightness.
    if (aeroWallet.z >= 3 && max(max(Color.r, Color.g), Color.b) <= 0.251) aeroWallet.z = -1;
}


vec3 aeroboxHudPosition(vec3 pos) {
    vec2 ui = ceil(2.0 / vec2(ProjMat[0][0], -ProjMat[1][1]));
    if (pos.y < ui.y || ProjMat[3].x != -1.0) return pos;
    int bit = int(pos.y) >> 13;
    if (((bit >> 10) & 1) == 0) return pos;
    int id = bit - (1 << 10);
    pos.x -= 0.5 * ui.x;
    if (id >= 1 && id <= 3) pos.x += ui.x;
    pos.y -= float((bit << 13) + 4095 + 10);
    if (id == 1 || id == 2) pos.y += 0.5 * ui.y;
    if (id == 3) pos.y += ui.y;
    if (id == 2 || id == 3) pos.z += 2.0;
    return pos;
}

void main() {
    aeroWalletGlyph();
    gl_Position = ProjMat * ModelViewMat * vec4(aeroboxHudPosition(Position), 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
