#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};

layout(location = 0) in vec4 vertexColor;
layout(location = 1) in vec2 aeroboxGuiPosition;
layout(location = 2) in vec2 aeroboxQuadUV;
layout(location = 3) flat in float aeroboxGuiWidth;
layout(location = 0) out vec4 fragColor;

bool closeTo(float a, float b) {
    return abs(a - b) < 0.15;
}

bool rowGrid(float value) {
    return abs(value - round(value / 9.0) * 9.0) < 0.15;
}

bool tabColumn(float left, float width, float screenWidth) {
    screenWidth = round(screenWidth);
    float center = floor(screenWidth * 0.5);
    float columnWidth = round(width);
    if (!closeTo(width, columnWidth) || columnWidth < 21.0) return false;
    for (int columns = 1; columns <= 4; columns++) {
        float gaps = 5.0 * float(columns - 1);
        if (columnWidth * float(columns) > screenWidth - 50.0) continue;
        float origin = center - floor((columnWidth * float(columns) + gaps) * 0.5);
        float step = columnWidth + 5.0;
        float column = round((left - origin) / step);
        if (column >= 0.0 && column < float(columns) && closeTo(left, origin + column * step)) return true;
    }
    return false;
}

void main() {
    // Recover the entire rectangle, rather than filtering individual pixels
    // in a broad screen region. Derivatives run before any divergent branch.
    float du = dFdx(aeroboxQuadUV.x);
    float dv = dFdy(aeroboxQuadUV.y);
    bool validQuad = abs(du) > 0.000001 && abs(dv) > 0.000001;
    vec2 span = vec2(dFdx(aeroboxGuiPosition.x) / (validQuad ? du : 1.0),
                     dFdy(aeroboxGuiPosition.y) / (validQuad ? dv : 1.0));
    vec2 origin = aeroboxGuiPosition - aeroboxQuadUV * span;
    vec2 lo = min(origin, origin + span);
    vec2 hi = max(origin, origin + span);
    vec2 size = hi - lo;
    bool centered = abs((lo.x + hi.x) * 0.5 - floor(aeroboxGuiWidth * 0.5)) < 1.1;

    // Vanilla uses the widest of the header, footer and complete player grid.
    // Player columns have five-pixel gaps, including when the columns are width-capped.
    float panelWidth = round(size.x);
    bool tabWidth = closeTo(size.x, panelWidth) && mod(panelWidth, 2.0) == 0.0
                    && panelWidth >= 258.0 && panelWidth <= max(260.0, aeroboxGuiWidth - 33.0);
    bool blackHalf = all(lessThan(abs(vertexColor.rgb), vec3(0.001)))
                     && abs(vertexColor.a - 128.0 / 255.0) < 0.001;
    bool header = closeTo(lo.y, 9.0)
                  && (closeTo(size.y, 55.0) || closeTo(size.y, 64.0));
    bool list = (closeTo(lo.y, 64.0) || closeTo(lo.y, 73.0))
                && size.y >= 9.9 && size.y <= 181.1 && rowGrid(size.y - 1.0);
    bool footer = lo.y >= 73.9 && lo.y <= 254.1 && rowGrid(lo.y - 2.0)
                  && (closeTo(size.y, 28.0) || closeTo(size.y, 37.0));

    bool whiteRow = all(lessThan(abs(vertexColor.rgb - vec3(1.0)), vec3(0.001)))
                    && abs(vertexColor.a - 32.0 / 255.0) < 0.001;
    bool playerRow = whiteRow && closeTo(size.y, 8.0)
                     && lo.y >= 64.9 && lo.y <= 245.1 && rowGrid(lo.y - 2.0)
                     && tabColumn(lo.x, size.x, aeroboxGuiWidth);

    if (validQuad && ((centered && tabWidth && blackHalf && (header || list || footer)) || playerRow)) {
        discard;
    }
    if (vertexColor.a == 0.0) discard;
    fragColor = vertexColor * ColorModulator;
}
