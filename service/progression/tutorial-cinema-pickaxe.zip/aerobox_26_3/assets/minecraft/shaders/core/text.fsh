#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

#include <minecraft:globals.glsl>
layout(location = 4) flat in ivec3 aeroWallet;
layout(location = 5) in vec2 aeroWalletUV;

vec4 aeroWalletColor() {
    ivec2 pixel = clamp(ivec2(floor(aeroWalletUV * vec2(27.0, 22.0))), ivec2(0), ivec2(26, 21));
    if (aeroWallet.z >= 3) pixel = clamp(ivec2(floor(aeroWalletUV * 22.0)), ivec2(0), ivec2(21));
    else if (pixel.x >= 22) {
        ivec2 fallbackPixel = (2 * pixel + 1) * ivec2(243, 198) / ivec2(54, 44);
        vec4 rim = texelFetch(Sampler0, aeroWallet.xy + fallbackPixel, 0);
        return floor(rim * 255.0 / 16.0 + 0.0001) / 15.0;
    }
    bool coin = aeroWallet.z == 1 || aeroWallet.z == 3;
    int frame = int(floor(fract(GameTime * (coin ? 273.0 : 375.0)) * (coin ? 88.0 : 64.0)));
    int index = frame * 484 + pixel.y * 22 + pixel.x;
    ivec2 address = ivec2(index % 243, 1 + index / 243);
    ivec4 packedPixel = ivec4(round(texelFetch(Sampler0, aeroWallet.xy + address, 0) * 255.0));
    return vec4(packedPixel & ivec4(15)) / 15.0;
}


void main() {
    if (aeroWallet.z < 0) discard;
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = aeroWallet.z == 0 ? texture(Sampler0, texCoord0) : aeroWalletColor();
    #endif

    vec4 aeroboxTint = aeroWallet.z >= 3 ? vec4(1.0, 1.0, 1.0, vertexColor.a) : vertexColor;
    vec4 color = texColor * aeroboxTint * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
