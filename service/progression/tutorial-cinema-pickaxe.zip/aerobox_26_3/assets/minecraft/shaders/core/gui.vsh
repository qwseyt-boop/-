#version 330
#extension GL_ARB_separate_shader_objects : require

// Matches the vanilla 1.21.11 GUI uniform blocks.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 0) out vec4 vertexColor;
layout(location = 1) out vec2 aeroboxGuiPosition;
layout(location = 2) out vec2 aeroboxQuadUV;
layout(location = 3) flat out float aeroboxGuiWidth;

void main() {
    vec4 position = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * position;
    vertexColor = Color;
    aeroboxGuiPosition = position.xy;
    // ColoredRectangleRenderState emits four vertices per indexed quad.
    int corner = gl_VertexIndex % 4;
    aeroboxQuadUV = vec2(corner >= 2 ? 1.0 : 0.0,
                        corner == 1 || corner == 2 ? 1.0 : 0.0);
    aeroboxGuiWidth = abs(2.0 / ProjMat[0][0]);
}
