#version 150
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 0
#moj_import <fog.glsl>
#if SHADER_VERSION >= 2
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#else
uniform vec4 ColorModulator;uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float vertexDistance;
#endif
uniform sampler2D Sampler0;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#if SHADER_VERSION >= 2
#moj_import <globals.glsl>
#else
uniform float GameTime;uniform vec2 ScreenSize;
#endif
flat in int abJoinKind;
flat in ivec2 abJoinOrigin;
flat in float abJoinSeconds;
in vec2 abJoinUV;

float abEase(float a, float b, float t) { return smoothstep(a, b, t); }
float abOut(float t) { return 1.0 - pow(1.0 - clamp(t, 0.0, 1.0), 3.0); }
vec4 abSample(vec2 pixel, vec2 lo, vec2 hi) {
    // Manual bilinear sampling never reads another glyph in the font atlas.
    pixel = clamp(pixel, lo, hi);
    ivec2 a = ivec2(floor(pixel));
    ivec2 b = min(a + ivec2(1), ivec2(hi));
    vec2 f = fract(pixel);
    vec4 c00 = texelFetch(Sampler0, abJoinOrigin + a, 0);
    vec4 c10 = texelFetch(Sampler0, abJoinOrigin + ivec2(b.x, a.y), 0);
    vec4 c01 = texelFetch(Sampler0, abJoinOrigin + ivec2(a.x, b.y), 0);
    vec4 c11 = texelFetch(Sampler0, abJoinOrigin + b, 0);
    // Interpolate premultiplied values to avoid dark fringes around transparent art.
    c00.rgb *= c00.a; c10.rgb *= c10.a; c01.rgb *= c01.a; c11.rgb *= c11.a;
    vec4 c = mix(mix(c00, c10, f.x), mix(c01, c11, f.x), f.y);
    if (c.a > 0.0001) c.rgb /= c.a;
    return c;
}
vec4 abRect(vec2 point, vec2 center, vec2 displaySize, vec2 sourceLo, vec2 sourceSize) {
    vec2 uv = (point - center) / displaySize + 0.5;
    if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) return vec4(0.0);
    return abSample(sourceLo + uv * (sourceSize - 1.0), sourceLo, sourceLo + sourceSize - 1.0);
}
vec4 abJoinFragment() {
    float t = abJoinSeconds;
    if (abJoinKind == 99 || t < 0.0 || t >= 6.2) return vec4(0.0);
    float exitFade = 1.0 - abEase(4.85, 5.65, t);
    if (abJoinKind == 0) {
        float opacity = 0.65 * abEase(0.0, 0.65, t) * (1.0 - abEase(5.35, 6.2, t));
        return vec4(0.012, 0.018, 0.03, opacity);
    }
    // Reference-height coordinates: independent of GUI scale and aspect ratio.
    vec2 p = (abJoinUV - 0.5) * vec2(ScreenSize.x / ScreenSize.y * 720.0, 720.0);
    float reveal = abOut((t - 1.55) / 0.65);
    float hide = abEase(3.35, 3.85, t);
    float spread = reveal * (1.0 - hide);
    float logoX = -88.0 * spread;
    if (abJoinKind == 1) {
        float arrive = abOut((t - 0.55) / 0.85);
        float size = 0.84 + 0.16 * arrive;
        vec2 center = vec2(logoX, -24.0 * (1.0 - arrive) + 26.0 * abEase(4.85, 5.65, t));
        vec4 c = abRect(p, center, vec2(180.0, 103.56) * size, vec2(0.0, 8.0), vec2(240.0, 138.0));
        c.a *= abEase(0.55, 1.0, t) * exitFade;
        return c;
    }
    if (abJoinKind == 2) {
        vec2 center = vec2(logoX + 204.0 - 28.0 * (1.0 - reveal), 1.0);
        vec4 c = abRect(p, center, vec2(190.0, 58.0), vec2(0.0, 8.0), vec2(240.0, 74.0));
        // The welcome slides from behind the logo, rather than crossing its face.
        if (p.x < logoX + 94.0) c.a = 0.0;
        c.a *= abEase(1.6, 2.05, t) * (1.0 - abEase(3.2, 3.7, t));
        return c;
    }
    float starTime = t - 3.95;
    if (starTime < 0.0 || starTime >= 1.0) return vec4(0.0);
    int frame = min(49, int(floor(starTime * 50.0)));
    if (frame / 16 != abJoinKind - 3) return vec4(0.0);
    int tile = frame % 16;
    vec2 source = vec2(float(tile % 4) * 58.0, 8.0 + float(tile / 4) * 58.0);
    vec4 c = abRect(p, vec2(logoX + 78.0, -48.0), vec2(115.0), source, vec2(58.0));
    c.a *= exitFade;
    return c;
}

void main() {if (abJoinKind >= 0) {fragColor = abJoinFragment(); if (fragColor.a <= 0.0001) discard; return;}vec4 texColor = texture(Sampler0, texCoord0);vec4 color = texColor * vertexColor * ColorModulator;if (color.a < 0.1) {discard;}
#if SHADER_VERSION >= 2
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#else
fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
#endif
}