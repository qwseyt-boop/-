#version 150
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 0
#moj_import <fog.glsl>
#if SHADER_VERSION >= 2
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#else
uniform vec4 ColorModulator;uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float vertexDistance;
#endif
uniform sampler2D Sampler0;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;
#if SHADER_VERSION >= 2
#moj_import <globals.glsl>
#else
uniform float GameTime;uniform vec2 ScreenSize;
#endif
flat in int abJoinKind;
flat in int abBobbyPhase;
flat in ivec2 abBobbyValue;
flat in ivec2 abJoinOrigin;
flat in float abJoinSeconds;
in vec2 abJoinUV;

float abEase(float a, float b, float t) { return smoothstep(a, b, t); }
float abOut(float t) { return 1.0 - pow(1.0 - clamp(t, 0.0, 1.0), 3.0); }
vec4 abSample(vec2 pixel, vec2 lo, vec2 hi) {
    // Manual bilinear sampling never reads another glyph in the font atlas.
    pixel = clamp(pixel, lo, hi);
    ivec2 a = ivec2(floor(pixel));
    ivec2 b = min(a + ivec2(1), ivec2(hi));
    vec2 f = fract(pixel);
    vec4 c00 = texelFetch(Sampler0, abJoinOrigin + a, 0);
    vec4 c10 = texelFetch(Sampler0, abJoinOrigin + ivec2(b.x, a.y), 0);
    vec4 c01 = texelFetch(Sampler0, abJoinOrigin + ivec2(a.x, b.y), 0);
    vec4 c11 = texelFetch(Sampler0, abJoinOrigin + b, 0);
    // Interpolate premultiplied values to avoid dark fringes around transparent art.
    c00.rgb *= c00.a; c10.rgb *= c10.a; c01.rgb *= c01.a; c11.rgb *= c11.a;
    vec4 c = mix(mix(c00, c10, f.x), mix(c01, c11, f.x), f.y);
    if (c.a > 0.0001) c.rgb /= c.a;
    return c;
}
vec4 abRect(vec2 point, vec2 center, vec2 displaySize, vec2 sourceLo, vec2 sourceSize) {
    vec2 uv = (point - center) / displaySize + 0.5;
    if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) return vec4(0.0);
    if (abJoinKind == 2) {
        // Keep the server's bitmap lettering crisp. Art still uses premultiplied bilinear filtering.
        ivec2 pixel = ivec2(sourceLo + min(floor(uv * sourceSize), sourceSize - 1.0));
        return texelFetch(Sampler0, abJoinOrigin + pixel, 0);
    }
    return abSample(sourceLo + uv * (sourceSize - 1.0), sourceLo, sourceLo + sourceSize - 1.0);
}
vec4 abJoinFragment() {
    if (abJoinKind == 7) {
        if (abBobbyValue.x == -1) return vec4(1.0, 1.0, 1.0, float(abBobbyValue.y) / 255.0);
        if (abBobbyValue.x == -2) {
            float widthRatio = ScreenSize.x / ScreenSize.y / (16.0 / 9.0);
            vec2 fit = min(vec2(1.0), vec2(widthRatio, 1.0 / widthRatio));
            vec2 uv = (abJoinUV - 0.5) * fit + 0.5;
            ivec2 pixel = ivec2(clamp(uv, 0.0, 0.9999) * vec2(240.0, 134.0));
            return vec4(texelFetch(Sampler0, abJoinOrigin + pixel + ivec2(0, 2), 0).rgb, 1.0);
        }

        // Opacity is driven by monotonic server time, independent of client/world clock drift.
        float alpha=float(abBobbyValue.y)/255.0;
        if(abJoinUV.y<0.12 || abJoinUV.y>0.88)alpha=max(alpha,float(abBobbyValue.x)/255.0);
        return vec4(0.0,0.0,0.0,alpha);
    }
    if (abJoinKind == 8 || abJoinKind == 9) {
        if(abJoinUV.y < 0.03 || abJoinUV.y > 0.96) return vec4(0.0);
        ivec2 pixel = ivec2(clamp(floor(abJoinUV * 240.0),vec2(0.0),vec2(239.0)));
        if (abJoinKind == 8 && pixel.y < 102 &&
            int(round(texelFetch(Sampler0, abJoinOrigin + ivec2(3, 0), 0).r * 255.0)) == 77) {
            int letters = int(round(texelFetch(Sampler0, abJoinOrigin + ivec2(2, 0), 0).r * 255.0));
            if (abBobbyValue.y != 1 || abBobbyValue.x < letters || pixel.y < 65 || pixel.y >= 91) return vec4(0.0);
            vec2 src = (abJoinUV * 240.0 - vec2(120.0, 65.0)) / 1.625 + vec2(120.0, 44.0);
            return texelFetch(Sampler0, abJoinOrigin + ivec2(floor(src)), 0);
        }
        if(pixel.y>=127) {
            if(abJoinKind==8 && abBobbyValue.x<int(round(texelFetch(Sampler0,abJoinOrigin+ivec2(2,0),0).r*255.0)))return vec4(0.0);
            int top=abJoinKind==9?130:(pixel.y>=139?139:127);
            int sourceY=abJoinKind==8 && top==139?184:160;
            if(pixel.y<top || pixel.y>=top+12) return vec4(0.0);
            vec2 src=(abJoinUV*240.0-vec2(120.0,float(top)))/0.73+vec2(120.0,float(sourceY));
            if(src.x<0.0 || src.x>=240.0 || src.y>=float(sourceY+16))return vec4(0.0);
            return texelFetch(Sampler0,abJoinOrigin+ivec2(floor(src)),0);
        }
        if (abJoinKind == 8 && pixel.y >= 102 && pixel.y < 118) {
            int cutoff=int(round(texelFetch(Sampler0,abJoinOrigin+ivec2(clamp(abBobbyValue.x,0,239),1),0).r*255.0));
            if(pixel.x >= cutoff) return vec4(0.0);
        }
        if (abJoinKind == 9 && pixel.y >= 106 && pixel.y < 122) {
            int value=clamp(abBobbyValue.x,0,100);
            int count=value>=100?3:(value>=10?2:1);
            int symbols[4];symbols[0]=count==3?value/100:(count==2?value/10:value);
            symbols[1]=count==3?(value/10)%10:(count==2?value%10:10);
            symbols[2]=count==3?value%10:10;symbols[3]=10;
            int widths[4];int total=0;
            for(int i=0;i<4;i++){widths[i]=int(round(texelFetch(Sampler0,abJoinOrigin+ivec2(10+symbols[i],0),0).r*255.0));if(i<=count)total+=widths[i];}
            int left=(240-total)/2;
            for(int i=0;i<4;i++){
                if(i>count)break;
                if(pixel.x>=left && pixel.x<left+widths[i])return texelFetch(Sampler0,abJoinOrigin+ivec2(symbols[i]*18+pixel.x-left,32+pixel.y-106),0);
                left+=widths[i];
            }
            int dotWidth=int(round(texelFetch(Sampler0,abJoinOrigin+ivec2(21,0),0).r*255.0));
            if(pixel.x>=left && pixel.x<left+dotWidth*clamp(abBobbyValue.y,0,3))return texelFetch(Sampler0,abJoinOrigin+ivec2(198+(pixel.x-left)%dotWidth,32+pixel.y-106),0);
            return vec4(0.0);
        }
        if(abJoinKind==9 && pixel.y<100)return vec4(0.0);
        return texelFetch(Sampler0, abJoinOrigin + pixel, 0);
    }

    float t = abJoinSeconds;
    if (abJoinKind == 99 || t < 0.0 || t >= 6.2) return vec4(0.0);
    float exitFade = 1.0 - abEase(4.85, 5.65, t);
    if (abJoinKind == 0) {
        float opacity = 0.65 * abEase(0.0, 0.65, t) * (1.0 - abEase(5.35, 6.2, t));
        return vec4(0.012, 0.018, 0.03, opacity);
    }
    // Reference-height coordinates: independent of GUI scale and aspect ratio.
    vec2 p = (abJoinUV - 0.5) * vec2(ScreenSize.x / ScreenSize.y * 720.0, 720.0);
    float reveal = abOut((t - 1.55) / 0.65);
    float hide = abEase(3.35, 3.85, t);
    float spread = reveal * (1.0 - hide);
    float logoX = -88.0 * spread;
    if (abJoinKind == 1) {
        float arrive = abOut((t - 0.55) / 0.85);
        float size = 0.84 + 0.16 * arrive;
        vec2 center = vec2(logoX, -24.0 * (1.0 - arrive) + 26.0 * abEase(4.85, 5.65, t));
        vec4 c = abRect(p, center, vec2(180.0, 103.56) * size, vec2(0.0, 8.0), vec2(240.0, 138.0));
        c.a *= abEase(0.55, 1.0, t) * exitFade;
        return c;
    }
    if (abJoinKind == 2) {
        vec2 center = vec2(logoX + 204.0 - 28.0 * (1.0 - reveal), 1.0);
        vec4 c = abRect(p, center, vec2(190.0, 58.0), vec2(0.0, 8.0), vec2(240.0, 74.0));
        // The welcome slides from behind the logo, rather than crossing its face.
        if (p.x < logoX + 94.0) c.a = 0.0;
        c.a *= abEase(1.6, 2.05, t) * (1.0 - abEase(3.2, 3.7, t));
        return c;
    }
    float starTime = t - 3.95;
    if (starTime < 0.0 || starTime >= 1.0) return vec4(0.0);
    int frame = min(49, int(floor(starTime * 50.0)));
    if (frame / 16 != abJoinKind - 3) return vec4(0.0);
    int tile = frame % 16;
    vec2 source = vec2(float(tile % 4) * 58.0, 8.0 + float(tile / 4) * 58.0);
    vec4 c = abRect(p, vec2(logoX + 78.0, -48.0), vec2(115.0), source, vec2(58.0));
    c.a *= exitFade;
    return c;
}


flat in ivec3 aeroWallet;
in vec2 aeroWalletUV;

vec4 aeroWalletColor() {
    ivec2 pixel = clamp(ivec2(floor(aeroWalletUV * vec2(27.0, 22.0))), ivec2(0), ivec2(26, 21));
    if (aeroWallet.z >= 3) pixel = clamp(ivec2(floor(aeroWalletUV * 22.0)), ivec2(0), ivec2(21));
    else if (pixel.x >= 22) return texelFetch(Sampler0, aeroWallet.xy + pixel, 0);
    bool coin = aeroWallet.z == 1 || aeroWallet.z == 3;
    int frame = int(floor(fract(GameTime * (coin ? 273.0 : 375.0)) * (coin ? 88.0 : 64.0)));
    ivec2 tile = ivec2(frame % 11, frame / 11 + 1) * 22;
    return texelFetch(Sampler0, aeroWallet.xy + tile + pixel, 0);
}

void main() {if (aeroWallet.z < 0) discard;if (abJoinKind >= 0) {fragColor = abJoinFragment(); if (fragColor.a <= 0.0001) discard; return;}vec4 texColor = aeroWallet.z == 0 ? texture(Sampler0, texCoord0) : aeroWalletColor();vec4 color = texColor * (aeroWallet.z >= 3 ? vec4(1.0, 1.0, 1.0, vertexColor.a) : vertexColor) * ColorModulator;if (color.a < 0.1) {discard;}
#if SHADER_VERSION >= 2
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#else
fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
#endif
}