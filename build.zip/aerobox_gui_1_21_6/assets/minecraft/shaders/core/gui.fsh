#version 150

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
    float LineWidth;
};

in vec4 vertexColor;
noperspective in vec2 aeroboxGuiPosition;
noperspective in vec2 aeroboxQuadUV;
flat in float aeroboxGuiWidth;
out vec4 fragColor;

bool closeTo(float a, float b) {
    return abs(a - b) < 0.15;
}

bool rowGrid(float value) {
    return abs(value - round(value / 9.0) * 9.0) < 0.15;
}

void main() {
    // Recover the entire rectangle, rather than filtering individual pixels
    // in a broad screen region. Derivatives run before any divergent branch.
    float du = dFdx(aeroboxQuadUV.x);
    float dv = dFdy(aeroboxQuadUV.y);
    bool validQuad = abs(du) > 0.000001 && abs(dv) > 0.000001;
    vec2 span = vec2(dFdx(aeroboxGuiPosition.x) / (validQuad ? du : 1.0),
                     dFdy(aeroboxGuiPosition.y) / (validQuad ? dv : 1.0));
    vec2 origin = aeroboxGuiPosition - aeroboxQuadUV * span;
    vec2 lo = min(origin, origin + span);
    vec2 hi = max(origin, origin + span);
    vec2 size = hi - lo;
    bool centered = abs((lo.x + hi.x) * 0.5 - floor(aeroboxGuiWidth * 0.5)) < 1.1;

    // The 257-pixel custom panel yields a 258-pixel native backdrop.
    // Permit the adjacent even width if font measurement rounds differently.
    bool panelWidth = closeTo(size.x, 258.0) || closeTo(size.x, 260.0);
    bool blackHalf = all(lessThan(abs(vertexColor.rgb), vec3(0.001)))
                     && abs(vertexColor.a - 128.0 / 255.0) < 0.001;
    bool header = closeTo(lo.y, 9.0)
                  && (closeTo(size.y, 55.0) || closeTo(size.y, 64.0));
    bool list = (closeTo(lo.y, 64.0) || closeTo(lo.y, 73.0))
                && size.y >= 9.9 && size.y <= 181.1 && rowGrid(size.y - 1.0);
    bool footer = lo.y >= 73.9 && lo.y <= 254.1 && rowGrid(lo.y - 2.0)
                  && (closeTo(size.y, 28.0) || closeTo(size.y, 37.0));

    bool whiteRow = all(lessThan(abs(vertexColor.rgb - vec3(1.0)), vec3(0.001)))
                    && abs(vertexColor.a - 32.0 / 255.0) < 0.001;
    bool playerRow = closeTo(size.y, 8.0) && size.x >= 21.0 && size.x <= 258.1
                     && lo.y >= 64.9 && lo.y <= 245.1 && rowGrid(lo.y - 2.0);

    if (validQuad && centered &&
        ((panelWidth && blackHalf && (header || list || footer)) ||
         (whiteRow && playerRow))) {
        discard;
    }
    if (vertexColor.a == 0.0) discard;
    fragColor = vertexColor * ColorModulator;
}
