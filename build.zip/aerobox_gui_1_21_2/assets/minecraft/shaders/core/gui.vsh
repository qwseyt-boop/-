#version 150

// Matches the vanilla 1.21.11 GUI uniform blocks.
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

in vec3 Position;
in vec4 Color;
out vec4 vertexColor;
noperspective out vec2 aeroboxGuiPosition;
noperspective out vec2 aeroboxQuadUV;
flat out float aeroboxGuiWidth;

void main() {
    vec4 position = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * position;
    vertexColor = Color;
    aeroboxGuiPosition = position.xy;
    // ColoredRectangleRenderState emits four vertices per indexed quad.
    int corner = gl_VertexID % 4;
    aeroboxQuadUV = vec2(corner >= 2 ? 1.0 : 0.0,
                        corner == 1 || corner == 2 ? 1.0 : 0.0);
    aeroboxGuiWidth = abs(2.0 / ProjMat[0][0]);
}
