#version 150
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 2
#moj_import <fog.glsl>
#moj_import <sample_lightmap.glsl>
#if SHADER_VERSION >= 2
#moj_import <dynamictransforms.glsl>
#moj_import <projection.glsl>
#moj_import <globals.glsl>
out float sphericalVertexDistance;out float cylindricalVertexDistance;
#else
uniform mat4 ProjMat;uniform mat4 ModelViewMat;uniform int FogShape;out float vertexDistance;uniform vec2 ScreenSize;uniform float GameTime;
#endif
in vec3 Position;in vec4 Color;in vec2 UV0;in ivec2 UV2;uniform sampler2D Sampler0;uniform sampler2D Sampler2;uniform vec3 ChunkOffset;out vec4 vertexColor;out vec2 texCoord0;out float applyColor;bool range(float t, float m1, float m2) {return t >= m1 && t <= m2;}bool range(vec2 t, vec2 m1, vec2 m2) {return range(t.x, m1.x, m2.x) && range(t.y, m1.y, m2.y);}bool range(vec3 t, vec3 m1, vec3 m2) {return range(t.x, m1.x, m2.x) && range(t.y, m1.y, m2.y) && range(t.z, m1.z, m2.z);}bool checkElement(float z) {if (z == 0) return true; else if (z == 1000) return true; else if (z == -90) return true; else if (z == 2800) return true; return false;}float fogDistance(vec3 pos, int shape) {if (shape == 0) {return length(pos);} else {float distXZ = length(pos.xz);float distY = abs(pos.y);return max(distXZ, distY);}}// Only our private bitmap font has this marker. All other text keeps BetterHud's path.
flat out int abJoinKind;
flat out int abBobbyPhase;
flat out ivec2 abBobbyValue;
flat out ivec2 abJoinOrigin;
flat out float abJoinSeconds;
out vec2 abJoinUV;

bool abJoinVertex() {
    abJoinKind = -1; abBobbyPhase = 255; abBobbyValue=ivec2(0);
    abJoinOrigin = ivec2(0);
    abJoinSeconds = 0.0;
    abJoinUV = vec2(0.0);
    // The negative font ascent is intentional. An unpatched client draws it offscreen.
    // Modern GUI rendering can bake the title's scale/translation into Position.
    // Identify the bitmap itself instead of assuming untransformed title coordinates.
    if (Position.y < 1000.0) return false;
    ivec2 size = textureSize(Sampler0, 0);
    // A 240x240 glyph occupies its own 256x256 font page. Avoid assumptions about
    // vertex ordering (including batching/quad sorting performed by client mods).
    ivec2 corner = ivec2(greaterThan(UV0 * vec2(size), vec2(120.0)));
    ivec2 origin = ivec2(round(UV0 * vec2(size))) - corner * 240;
    if (any(lessThan(origin, ivec2(0))) || any(greaterThanEqual(origin + ivec2(239), size))) return false;
    ivec4 magic = ivec4(round(texelFetch(Sampler0, origin, 0) * 255.0));
    if (any(notEqual(magic, ivec4(17, 231, 193, 255)))) return false;
    abJoinKind = int(round(texelFetch(Sampler0, origin + ivec2(1, 0), 0).r * 255.0)) - 1;
    abJoinOrigin = origin;
    abJoinUV = vec2(corner);
    if (abJoinKind == 10) {
        float start = floor(Color.r * 255.0 + 0.5) * 256.0 + floor(Color.g * 255.0 + 0.5);
        abJoinSeconds = mod(GameTime * 24000.0 - start + 24000.0, 24000.0) / 20.0;
        if (abJoinSeconds > 1198.0) abJoinSeconds = 0.0;
        gl_Position = vec4(abJoinUV.x * 2.0 - 1.0, 1.0 - abJoinUV.y * 2.0, -0.99991, 1.0);
        if (Color.b < 0.9) gl_Position = vec4(2.0, 2.0, 0.0, 1.0);
        vertexColor = vec4(1.0); texCoord0 = UV0;
#if SHADER_VERSION >= 2
        sphericalVertexDistance = 0.0; cylindricalVertexDistance = 0.0;
#else
        vertexDistance = 0.0;
#endif
        return true;
    }

    // Bobby private font: fullscreen dimmer or centered pre-rendered server lettering.
    if (abJoinKind >= 7 && abJoinKind <= 9) {
        if (Color.b < 0.9) { abJoinKind = 99; gl_Position = vec4(2.0,2.0,0.0,1.0); return true; }
        float fromClock = floor(Color.r * 255.0 + 0.5) * 256.0 + floor(Color.g * 255.0 + 0.5);
        abJoinSeconds = mod(GameTime * 24000.0 - fromClock + 24000.0, 24000.0) / 20.0;
        abBobbyPhase = int(floor(Color.b * 255.0 + 0.5));
        abBobbyValue = ivec2(round(Color.rg*255.0));
        vec2 quad = abJoinUV;
        if (abJoinKind >= 8) quad = (quad - 0.5) * vec2(480.0) / vec2(ScreenSize.x / ScreenSize.y * 720.0,720.0) + 0.5;
        gl_Position = vec4(quad.x*2.0-1.0,1.0-quad.y*2.0,abJoinKind==7?-0.9998:-0.9999,1.0);
        vertexColor = vec4(1.0); texCoord0 = UV0;
#if SHADER_VERSION >= 2
        sphericalVertexDistance = 0.0; cylindricalVertexDistance = 0.0;
#else
        vertexDistance = 0.0;
#endif
        return true;
    }

    float start = floor(Color.r * 255.0 + 0.5) * 256.0 + floor(Color.g * 255.0 + 0.5);
    abJoinSeconds = mod(GameTime * 24000.0 - start + 24000.0, 24000.0) / 20.0;
    // Drop the normal title shadow: its quarter-strength colour is not timing data.
    if (Color.b < 0.9 || abJoinKind < 0 || abJoinKind > 6) abJoinKind = 99;
    float t = abJoinSeconds;
    vec2 center = vec2(0.0), extent = vec2(0.0);
    float enter = 1.0 - pow(1.0 - clamp((t - 1.55) / 0.65, 0.0, 1.0), 3.0);
    float spread = enter * (1.0 - smoothstep(3.35, 3.85, t));
    float logoX = -88.0 * spread;
    bool abVisible = t >= 0.0 && t < 6.2 && abJoinKind != 99;
    if (abJoinKind == 1) {
        float arrive = 1.0 - pow(1.0 - clamp((t - 0.55) / 0.85, 0.0, 1.0), 3.0);
        center = vec2(logoX, -24.0 * (1.0 - arrive) + 26.0 * smoothstep(4.85, 5.65, t));
        extent = vec2(180.0, 103.56) * (0.84 + 0.16 * arrive);
        abVisible = abVisible && t >= 0.55 && t < 5.65;
    } else if (abJoinKind == 2) {
        center = vec2(logoX + 204.0 - 28.0 * (1.0 - enter), 1.0);
        extent = vec2(190.0, 58.0);
        abVisible = abVisible && t >= 1.6 && t < 3.7;
    } else if (abJoinKind >= 3 && abJoinKind <= 6) {
        center = vec2(logoX + 78.0, -48.0);
        extent = vec2(115.0);
        int frame = min(49, int(floor((t - 3.95) * 50.0)));
        abVisible = abVisible && t >= 3.95 && t < 4.95 && frame / 16 == abJoinKind - 3;
    }
    // Only the dimmer is fullscreen. Art and inactive sprites do not shade the entire viewport.
    if (abJoinKind > 0 && abJoinKind < 7) {
        vec2 reference = vec2(ScreenSize.x / ScreenSize.y * 720.0, 720.0);
        abJoinUV = (center + (abJoinUV - 0.5) * extent) / reference + 0.5;
    }
    // Older GUI renderers keep the crosshair's depth when titles are drawn.
    // Draw in front of that depth, with distinct planes for the translucent layers.
    float sceneDepth = -0.999 - float(clamp(abJoinKind, 0, 6)) * 0.0001;
    gl_Position = vec4(abJoinUV.x * 2.0 - 1.0, 1.0 - abJoinUV.y * 2.0, sceneDepth, 1.0);
    if (!abVisible) gl_Position = vec4(2.0, 2.0, 0.0, 1.0);
    vertexColor = vec4(1.0);
    texCoord0 = UV0;
#if SHADER_VERSION >= 2
    sphericalVertexDistance = 0.0;
    cylindricalVertexDistance = 0.0;
#else
    vertexDistance = 0.0;
#endif
    return true;
}

void main() {if (abJoinVertex()) return;vec3 pos = Position;vec2 ui = ceil(2 / vec2(ProjMat[0][0], -ProjMat[1][1]));vec2 uiScreen = ui / ScreenSize;vec3 color = Color.xyz;applyColor = 0;vertexColor = Color * sample_lightmap(Sampler2, UV2);if (pos.y >= ui.y && ProjMat[3].x == -1) {int bit = int(pos.y) >> HEIGHT_BIT;if (((bit >> MAX_BIT) & 1) == 1) {int id = bit - (1 << MAX_BIT);pos.x -= 0.5 * ui.x;pos.y -= (bit << HEIGHT_BIT) + ADD_OFFSET + DEFAULT_OFFSET;float xGui = 0;float yGui = 0;float layer = 0;float opacity = 1;bool outline = false;int property = 0;switch (id) {case 1:xGui = ui.x * 100.0 / 100.0;yGui = ui.y * 50.0 / 100.0;break;case 2:xGui = ui.x * 100.0 / 100.0;yGui = ui.y * 50.0 / 100.0;layer = 2;break;case 3:xGui = ui.x * 100.0 / 100.0;yGui = ui.y * 100.0 / 100.0;layer = 2;break;case 4:xGui = ui.x * 50.0 / 100.0;pos.x *= (ui.x + 8.0) / 2048.0;pos.x += 4.0;pos.y *= ui.y * 0.12 / 72.0;break;case 5:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 88.0 / 100.0;layer = 1;break;case 6:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 88.0 / 100.0;layer = 3;break;case 7:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 90.4 / 100.0;layer = 1;break;case 8:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 90.4 / 100.0;layer = 3;break;case 9:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 92.8 / 100.0;layer = 1;break;case 10:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 92.8 / 100.0;layer = 3;break;case 11:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 95.2 / 100.0;layer = 1;break;case 12:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 95.2 / 100.0;layer = 3;break;case 13:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 97.6 / 100.0;layer = 1;break;case 14:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 97.6 / 100.0;layer = 3;break;case 15:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 100.0 / 100.0;pos.x *= (ui.x + 8.0) / 2048.0;pos.x += 4.0;pos.y *= ui.y * 0.12 / 72.0;break;case 16:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 100.0 / 100.0;layer = 1;break;case 17:xGui = ui.x * 50.0 / 100.0;yGui = ui.y * 100.0 / 100.0;layer = 3;break;}
#if SHADER_VERSION < 2
vertexColor = (checkElement(pos.z) && !outline) ? vec4(0) : Color * sample_lightmap(Sampler2, UV2) * vec4(1, 1, 1, opacity);
#else
vertexColor = Color * sample_lightmap(Sampler2, UV2) * vec4(1, 1, 1, opacity);
#endif
if ((property & 1) > 0) {pos.y += 4 * sin((GameTime * 1200 + pos.x / ui.x) * 3.1415 * 2);}if ((property & 2) > 0) {int hash = int(pos.x) * int(pos.y);float time = GameTime * 1200;hash = 31 * (hash + int(vertexColor.x + time));float r = float(hash % 224 + 32) / 255;hash = 31 * (hash + int(vertexColor.y + time));float g = float(hash % 224 + 32) / 255;hash = 31 * (hash + int(vertexColor.z + time));float b = float(hash % 224 + 32) / 255;float maxValue = max(max(r, g), b);vertexColor = vec4(pow(r / maxValue, 3), pow(g / maxValue, 3), pow(b / maxValue, 3), vertexColor.w);}if ((property & 4) > 0) {int hash = int(pos.x) * int(pos.y);float time = GameTime * 1200;hash = 31 * (hash + int(vertexColor.x + time));float r = vertexColor.x + float(hash % 64) / 255;hash = 31 * (hash + int(vertexColor.y + time));float g = vertexColor.y + float(hash % 64) / 255;hash = 31 * (hash + int(vertexColor.z + time));float b = vertexColor.z + float(hash % 64) / 255;vertexColor = vec4(r, g, b, vertexColor.w);}pos.x += xGui;pos.y += yGui;pos.z += layer;}} else {}
#if SHADER_VERSION >= 2
sphericalVertexDistance = fog_spherical_distance(pos);cylindricalVertexDistance = fog_cylindrical_distance(pos);
#else
vertexDistance = fogDistance(pos, FogShape);
#endif
texCoord0 = UV0;gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
            ivec3 bobbyButton = ivec3(round(Color.rgb*255.0));
            if(all(equal(bobbyButton,ivec3(131,217,166))) || all(equal(bobbyButton,ivec3(240,154,129))))
                gl_Position.z = -0.99998 * gl_Position.w;
            }