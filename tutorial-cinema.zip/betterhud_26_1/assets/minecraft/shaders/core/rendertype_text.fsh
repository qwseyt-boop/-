#version 150
#define HEIGHT_BIT 13
#define MAX_BIT 10
#define ADD_OFFSET 4095
#define DEFAULT_OFFSET 10
#define SHADER_VERSION 3
#moj_import <fog.glsl>
#if SHADER_VERSION >= 2
#moj_import <dynamictransforms.glsl>
in float sphericalVertexDistance;in float cylindricalVertexDistance;
#else
uniform vec4 ColorModulator;uniform float FogStart;uniform float FogEnd;uniform vec4 FogColor;in float vertexDistance;
#endif
uniform sampler2D Sampler0;in vec4 vertexColor;in vec2 texCoord0;out vec4 fragColor;#moj_import <globals.glsl>

flat in ivec3 aeroWallet;
in vec2 aeroWalletUV;

vec4 aeroWalletColor() {
    ivec2 pixel = clamp(ivec2(floor(aeroWalletUV * vec2(27.0, 22.0))), ivec2(0), ivec2(26, 21));
    if (pixel.x >= 22) return texelFetch(Sampler0, aeroWallet.xy + pixel, 0);
    bool coin = aeroWallet.z == 1;
    int frame = int(floor(fract(GameTime * (coin ? 273.0 : 375.0)) * (coin ? 88.0 : 64.0)));
    ivec2 tile = ivec2(frame % 11, frame / 11 + 1) * 22;
    return texelFetch(Sampler0, aeroWallet.xy + tile + pixel, 0);
}

void main() {vec4 texColor = aeroWallet.z == 0 ? texture(Sampler0, texCoord0) : aeroWalletColor();vec4 color = texColor * vertexColor * ColorModulator;if (color.a < 0.1) {discard;}
#if SHADER_VERSION >= 2
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#else
fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
#endif
}